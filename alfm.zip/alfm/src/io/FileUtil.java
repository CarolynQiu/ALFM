package io;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map.Entry;
import struct.Error;

public class FileUtil {
	public static void ReadFile(String dir, ArrayList<String> lines, String code){
		BufferedReader br = null;
		
		try{
			br = new BufferedReader(new InputStreamReader(new FileInputStream(dir), code));
			String line = null;
			while((line = br.readLine()) != null){
				if(!line.isEmpty()){
					lines.add(line);
				}
			}
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			try{
				br.close();
			}catch(Exception e){
				e.printStackTrace();
			}
		}
	}
	
	public static void writeLines(String dir, ArrayList<String> counts, String code) {
		BufferedWriter writer = null;
		File file = null;
		try {
			file = new File(dir);
			if(file.exists()){
				file.delete();
			}
			writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(file), code));

			for (int i = 0; i < counts.size(); i++) {
				writer.write(counts.get(i) + "\t\n");
			}

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (writer != null) {
				try {
					writer.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}
	
	public static void writeError(String dir, ArrayList<Error> counts, String code) {
		BufferedWriter writer = null;
		File file = null;
		try {
			file = new File(dir);
			if(file.exists()){
				file.delete();
			}
			writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(file), code));

			for (int i = 0; i < counts.size(); i++) {
				Error e = counts.get(i);
				writer.write(e.itemSN + "," + e.userSN + "," + e.err + "\n");
			}

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (writer != null) {
				try {
					writer.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}

	}
	
	public static void writeLines(String dir, HashMap<String, Integer> counts, String code) {
		BufferedWriter writer = null;
		File file = null;
		try {
			file = new File(dir);
			if(file.exists()){
				file.delete();
			}
			writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(file), code));

			Iterator<Entry<String, Integer>> iter = counts.entrySet().iterator();
			while (iter.hasNext()) {
				Entry<String, Integer> entry = iter.next();
				writer.write(entry.getKey() + "\t" + entry.getValue().toString() + "\r\n");
			}

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (writer != null) {
				try {
					writer.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}

	}
	
	public static void writeLines(String dir, double[][] counts, String code) {
		BufferedWriter writer = null;
		File file = null;
		try {
			file = new File(dir);
			if(file.exists()){
				file.delete();
			}
			writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(file), code));

			for(int i = 0; i < counts.length; i ++){
				for(int j = 0; j < 5; j ++){
					writer.write(counts[i][j] + "\t");
				}
				writer.write("\n");
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (writer != null) {
				try {
					writer.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}

	}
}
