package io;

import java.util.ArrayList;
import java.util.StringTokenizer;

public class ComUtil {
	public static void delim(String line, ArrayList<String> tokens, String delimiter){
		StringTokenizer st = new StringTokenizer(line, delimiter);
		
		while(st.hasMoreTokens()){
			tokens.add(st.nextToken());
		}
	}
}
