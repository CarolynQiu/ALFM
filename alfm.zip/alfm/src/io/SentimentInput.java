package io;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map.Entry;

import struct.Rating;

public class SentimentInput {
	public static void getMatices(String dataDir, String lexiconDir, ArrayList<Rating> ratings, ArrayList<HashMap<Integer, Double>> users, ArrayList<HashMap<Integer, Double>> items, String code, ArrayList<Integer> numbers){
		HashMap<String, Integer> sWordDict = new HashMap<String, Integer>();
		HashMap<String, Integer> nWordDict = new HashMap<String, Integer>();
		HashMap<String, Integer> userDict = new HashMap<String, Integer>();
		HashMap<String, Integer> itemDict = new HashMap<String, Integer>();
		HashMap<Integer, Double> sentimentScore = new HashMap<Integer, Double>();
		
		int sWordN = 0;
		int userN = 0;
		int itemN = 0;
		int nWordN = 0;
		
		ArrayList<String> lines = new ArrayList<String>();
		FileUtil.ReadFile(lexiconDir, lines, code);
		for(String line : lines){
			String[] temp = line.split("\t");
			sWordDict.put(temp[0], sWordN);
			sentimentScore.put(sWordN, Double.parseDouble(temp[1]));
			sWordN++;
		}
		lines.clear();
		
		File folder = new File(dataDir);
		if (folder.isDirectory()) {
			String[] fList = folder.list();

			for (int i = 0; i < fList.length; i++) {
				String fDir = fList[i];
				String itemID = fDir.substring(0, fDir.lastIndexOf("."));
				if (!itemDict.containsKey(itemID)) {
					itemDict.put(itemID, itemN);
					itemN ++;
					HashMap<Integer, Double> temp = new HashMap<Integer, Double>();
					items.add(temp);
				}

				FileUtil.ReadFile(dataDir + fDir, lines, code);

				for (String line : lines) {
					ArrayList<String> tokens = new ArrayList<String>();
					ComUtil.delim(line, tokens, "\t");
					if (tokens.size() == 4) {
						String userID = tokens.get(0);
						if (!userDict.containsKey(userID)) {
							userDict.put(userID, userN);
							userN ++;
							HashMap<Integer, Double> temp = new HashMap<Integer, Double>();
							users.add(temp);
						}
						int rating = Integer.parseInt(tokens.get(1).substring(0, tokens.get(1).indexOf("/")));
						String type = tokens.get(2);
						Rating r = new Rating(userDict.get(userID), itemDict.get(itemID), rating, type);
						ratings.add(r);

						String sentence = tokens.get(3);
						ArrayList<String> parts = new ArrayList<String>();
						ComUtil.delim(sentence, parts, " ");

						for (String part : parts) {
							int del = part.indexOf("/");
							String pos = part.substring(del + 1);
							String fWord = part.substring(0, del);
							fWord = fWord.toLowerCase();
							if(fWord.contains(".")){
								if(fWord.endsWith(".")){
									fWord = fWord.substring(0, fWord.length()-1);
								}else{
									fWord = fWord.substring(fWord.indexOf("."));
								}
							}
							
							String word = fWord.replaceAll("[^a-zA-Z]", "");
							if(word.isEmpty()||word.equals("")||word.length()<3){
								continue;
							}
							
							if(pos.startsWith("n")){
								if (!nWordDict.containsKey(word)) {
									nWordDict.put(word, nWordN);
									nWordN ++;
								}
							}
							
							int userSN = userDict.get(userID);
							int itemSN = itemDict.get(itemID);
							if(nWordDict.containsKey(word)){
								int wi = nWordDict.get(word);
								if (!users.get(userSN).containsKey(wi)) {
									users.get(userSN).put(wi, 1.0);
								} else {
									double temp = users.get(userSN).get(wi);
									users.get(userSN).put(wi, temp + 1.0);
								}
							}
							
							if(sWordDict.containsKey(word)){
								int wi = sWordDict.get(word);
								if (!items.get(itemSN).containsKey(wi)) {
									items.get(itemSN).put(wi, 1.0);
								} else {
									double temp = items.get(itemSN).get(wi);
									items.get(itemSN).put(wi, temp + 1.0);
								}
							}
						}
					}
				}
				lines.clear();
			}
			lines.clear();
		}
		
		System.out.println("Total Number of users��" + userDict.size());
		System.out.println("Total Number of items��" + itemDict.size());
		System.out.println("Total Number of reviews��" + ratings.size());
		System.out.println("Total Number of nouns����" + nWordDict.size());
		System.out.println("Total Number of sentiment words����" + sWordDict.size());
		numbers.add(userDict.size());
		numbers.add(itemDict.size());
		numbers.add(nWordDict.size());
		numbers.add(sWordDict.size());
			
		
		int userNum = userDict.size();
		for(int i = 0; i < userNum; i ++){
			HashMap<Integer, Double> user = users.get(i);
			Iterator<Entry<Integer, Double>> iter = user.entrySet().iterator();
			while(iter.hasNext()){
				Entry<Integer, Double> entry = iter.next();
				double newValue = 1/(1 + Math.exp(-entry.getValue()));
				users.get(i).put(entry.getKey(), newValue);
			}
		}
		
		int itemNum = itemDict.size();
		for(int i = 0; i < itemNum; i ++){
			HashMap<Integer, Double> item = items.get(i);
			Iterator<Entry<Integer, Double>> iter = item.entrySet().iterator();
			while(iter.hasNext()){
				Entry<Integer, Double> entry = iter.next();
				//System.out.println(entry.getValue());
				double newValue = 1/(1 + Math.exp(-entry.getValue())) * sentimentScore.get(entry.getKey());
				items.get(i).put(entry.getKey(), newValue);
			}
		}

		System.out.println("Data Processing Complete.");
		userDict.clear();
		itemDict.clear();
		nWordDict.clear();
		sWordDict.clear();
	}
}
