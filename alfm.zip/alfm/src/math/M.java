package math;

public class M {
	public static double[][] p(double[][] x, double[][] y){
		double[][] result = null;
		if(x[0].length == y.length){
			result = new double[x.length][y[0].length];
			for(int i = 0; i < x.length; i ++){
				for(int j = 0; j < y[0].length; j ++){
					for(int m = 0; m < y.length; m ++){
						result[i][j] += x[i][m]*y[m][j];
					}
				}
			}
		}else{
			System.out.print("前矩阵的列数和后矩阵的行数不一致，无法相乘。");
		}
		
		return result;
	}
	
	public static double[][] add(double[][] x, double[][] y){
		double[][] result = null;
		if(x.length == y.length && x[0].length == y[0].length){
			result = new double[x.length][y[0].length];
			for(int i = 0; i < x.length; i ++){
				for(int j = 0; j < x[0].length; j ++){
					result[i][j] += x[i][j] + y[i][j];
				}
			}
		}else{
			System.out.print("前矩阵的列数和后矩阵的行数不一致，无法相乘。");
		}
		
		return result;
	}
	
	public static double norm (double[][] x){
		double result = 0.0;
		for(int i = 0; i < x.length; i ++){
			for(int j = 0; j < x[0].length; j ++){
				result += Math.pow(x[i][j], 2);
			}
		}
		return result;
	}
}
