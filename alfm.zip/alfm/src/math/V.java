package math;

public class V {
	public static double[] add(double[] x, double[] y){
		double[] result = null;
		if(x.length == y.length){
			result = new double[x.length];
			for(int i = 0 ; i < x.length; i ++){
				result[i] = x[i] + y[i];
			}
		}else{
			System.out.println("向量纬度不一致，无法相加");
		}
		return result;
	}
	
	public static double dp(double[] x, double[] y){
		double result = 0.0;
		if(x.length == y.length){
			for(int i = 0 ; i < x.length; i ++){
				result += x[i]*y[i];
			}
		}else{
			System.out.println("向量纬度不一致，无法相乘");
		}
		return result;
	}
}
