package struct;

public class Error {
	public int userSN;
	public int itemSN;
	public double err;
	
	public Error(int userID, int itemID, double err){
		this.userSN = userID;
		this.itemSN = itemID;
		this.err = err;
	}
}
