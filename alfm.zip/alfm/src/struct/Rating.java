package struct;

public class Rating {
	public int userSN;
	public int itemSN;
	public int rating;
	public String type;
	
	public Rating(int userID, int itemID, int rating, String type){
		this.userSN = userID;
		this.itemSN = itemID;
		this.rating = rating;
		this.type = type;
	}
}
