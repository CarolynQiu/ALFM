package entry;

import io.ComUtil;
import io.FileUtil;

import java.io.File;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map.Entry;

//import model.PuLDA;
import model.PuiLDA;
import struct.Rating;

public class ALFMP {
	public static void main(String[] args) {
		String indir = "testdata/";         //path of data
		String code = "utf-8";

		ArrayList<Rating> ratings = new ArrayList<Rating>();
		int userNum = 0;
		int itemNum = 0;
		int wordNum = 0;
		ArrayList<HashMap<Integer, Double>> users = new ArrayList<HashMap<Integer, Double>>();
		ArrayList<HashMap<Integer, Double>> items = new ArrayList<HashMap<Integer, Double>>();

		HashMap<String, Integer> wordDict = new HashMap<String, Integer>();
		HashMap<String, Integer> userDict = new HashMap<String, Integer>();
		HashMap<String, Integer> itemDict = new HashMap<String, Integer>();

		int userN = 0;
		int itemN = 0;
		int wordN = 0;
		File folder = new File(indir);
		if (folder.isDirectory()) {
			String[] fList = folder.list();

			for (int i = 0; i < fList.length; i++) {
				String fDir = fList[i];
				String itemID = fDir.substring(0, fDir.lastIndexOf("."));
				if (!itemDict.containsKey(itemID)) {
					itemDict.put(itemID, itemN);
					itemN ++;
					HashMap<Integer, Double> temp = new HashMap<Integer, Double>();
					items.add(temp);
				}

				ArrayList<String> lines = new ArrayList<String>();
				FileUtil.ReadFile(indir + fDir, lines, code);

				for (String line : lines) {
					ArrayList<String> tokens = new ArrayList<String>();
					ComUtil.delim(line, tokens, "\t");
					if (tokens.size() == 4) {
						String userID = tokens.get(0);
						if (!userDict.containsKey(userID)) {
							userDict.put(userID, userN);
							userN ++;
							HashMap<Integer, Double> temp = new HashMap<Integer, Double>();
							users.add(temp);
						}
						int rating = Integer.parseInt(tokens.get(1).substring(0, tokens.get(1).indexOf("/")));
						String type = tokens.get(2);
						Rating r = new Rating(userDict.get(userID), itemDict.get(itemID), rating, type);
						ratings.add(r);

						String sentence = tokens.get(3);
						ArrayList<String> parts = new ArrayList<String>();
						ComUtil.delim(sentence, parts, " ");

						for (String part : parts) {
							int del = part.indexOf("/");
							String pos = part.substring(del + 1);
							if(pos.startsWith("n") || pos.startsWith("j") || pos.startsWith("v")){
								String fWord = part.substring(0, del);
								fWord = fWord.toLowerCase();
								if(fWord.contains(".")){
									if(fWord.endsWith(".")){
										fWord = fWord.substring(0, fWord.length()-1);
									}else{
										fWord = fWord.substring(fWord.indexOf(".") + 1);
									}
								}
								String word = fWord.replaceAll("[^a-zA-Z]", "");
								if(word.isEmpty()||word.equals("")||word.length()<3){
									continue;
								}

								if (!wordDict.containsKey(word)) {
									wordDict.put(word, wordN);
									wordN ++;
								}
								int userSN = userDict.get(userID);
								int itemSN = itemDict.get(itemID);
								int wi = wordDict.get(word);
									
								if (!users.get(userSN).containsKey(wi)) {
									users.get(userSN).put(wi, 1.0);
								} else {
									double temp = users.get(userSN).get(wi);
									users.get(userSN).put(wi, temp + 1.0);
								}
									
								if (!items.get(itemSN).containsKey(wi)) {
									items.get(itemSN).put(wi, 1.0);
								} else {
									double temp = items.get(itemSN).get(wi);
									items.get(itemSN).put(wi, temp + 1.0);
								}
							}
						}
					}
				}
				lines.clear();
				lines = null;
			}
		}

		userNum = userDict.size();
		itemNum = itemDict.size();
		wordNum = wordDict.size();
		System.out.println("Total Number of users��" + userDict.size());
		System.out.println("Total Number of items��" + itemDict.size());
		System.out.println("Total Number of reviews��" + ratings.size());
		System.out.println("Total Number of words����" + wordDict.size());
		//FileUtil.writeLines("e:\\output\\word.txt", wordDict, code);
		//FileUtil.writeLines("G:\\Experiment Result\\coldStart\\userdict", userDict, code);
		//FileUtil.writeLines("G:\\Experiment Result\\coldStart\\itemdict", itemDict, code);
		userDict=null;
		itemDict=null;
		wordDict=null;
		
		for(int i = 0; i < userNum; i ++){
			HashMap<Integer, Double> user = users.get(i);
			Iterator<Entry<Integer, Double>> iter = user.entrySet().iterator();
			while(iter.hasNext()){
				Entry<Integer, Double> entry = iter.next();
				double newValue = 1/(1 + Math.exp(-entry.getValue()));
				users.get(i).put(entry.getKey(), newValue);
			}
			iter = null;
		}
		
		for(int i = 0; i < itemNum; i ++){
			HashMap<Integer, Double> item = items.get(i);
			Iterator<Entry<Integer, Double>> iter = item.entrySet().iterator();
			while(iter.hasNext()){
				Entry<Integer, Double> entry = iter.next();
				double newValue = 1/(1 + Math.exp(-entry.getValue()));
				items.get(i).put(entry.getKey(), newValue);
			}
			iter = null;
		}

		System.out.println("data processing completed");
		int k = 5;
		int max = 100;
		int val = 10;
		double lumdaU = 0.2;
		double lumdaI = 0.2;
		double lumdaW = 0.2;
		double lumdaB = 0.2;
		double lumdaWu = 0.6;
		double lumdaWi = 1.0;

		/*double result = PuiLDA.train(ratings, users, items, wordNum, userNum,
				itemNum, k, max, lumdaWu, lumdaWi, lumdaU, lumdaI, lumdaW,
				lumdaB);
		
		
		System.out.println(indir + ":" + result);*/
		
		//for(double lumdaWu = 0.2; lumdaWu < 1.0; lumdaWu=lumdaWu + 0.2){
			//for(double lumdaWi = 0.2; lumdaWi < 2.0; lumdaWi=lumdaWi + 0.2){
				double[] mse = new double[val];
				for (int i = 0; i < val; i++) {
					mse[i] = PuiLDA.train(i, ratings, users, items, wordNum, userNum,
							itemNum, k, max, lumdaWu, lumdaWi, lumdaU, lumdaI, lumdaW,
							lumdaB);
					System.out.println("��" + i + "�Σ�" + mse[i]);
				}
				double mean = 0.0;
				double varice = 0.0;
				for (int i = 0; i < val; i++) {
					mean += mse[i];
				}

				mean /= val;
				BigDecimal bd = new BigDecimal(mean);
				bd = bd.setScale(3, BigDecimal.ROUND_HALF_UP);
				mean = bd.doubleValue();
				for (int i = 0; i < val; i++) {
					if (varice <= Math.abs(mse[i] - mean)) {
						varice = Math.abs(mse[i] - mean);
					}
				}
				bd = new BigDecimal(varice);
				bd = bd.setScale(3, BigDecimal.ROUND_HALF_UP);
				varice = bd.doubleValue();
				System.out.println("user weight:" + lumdaWu + ";\titem weight:" + lumdaWi + ";\tTestErr: " + mean + "+-" + varice);
			//}
		//}
	}
}
