package entry;

import io.SentimentInput;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;

import model.PartWorduiLDA;
import struct.Rating;

public class ALFMQ {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String dataDir = "testdata/";
		String lexiconDir = "SentiWordNet.txt";
		String code = "utf-8";

		ArrayList<Rating> ratings = new ArrayList<Rating>();
		ArrayList<Integer> numbers = new ArrayList<Integer>();
		ArrayList<HashMap<Integer, Double>> users = new ArrayList<HashMap<Integer, Double>>();
		ArrayList<HashMap<Integer, Double>> items = new ArrayList<HashMap<Integer, Double>>();

		SentimentInput.getMatices(dataDir, lexiconDir, ratings, users, items, code, numbers);
		int userNum = numbers.get(0);
		int itemNum = numbers.get(1);
		int nWordNum = numbers.get(2);
		int sWordNum = numbers.get(3);

		int k = 5;
		int max = 100;
		int val = 10;
		double lumdaU = 0.2;
		double lumdaI = 0.2;
		double lumdaW = 0.2;
		double lumdaB = 0.2;
		double lumdaWi = 0.6;
		double lumdaWu = 0.2;

		//for(double lumdaWu = 3.0; lumdaWu < 3.2; lumdaWu = lumdaWu + 0.2){
			//for(double lumdaWi = 1.4; lumdaWi < 2.0; lumdaWi = lumdaWi + 0.2){
				double[] mse = new double[val];
				for (int i = 0; i < val; i++) {
					mse[i] = PartWorduiLDA.train(ratings, users, items, nWordNum, sWordNum, userNum,
							itemNum, k, max, lumdaWu, lumdaWi, lumdaU, lumdaI, lumdaW,
							lumdaB);
					System.out.println("Test" + i + "��" + mse[i]);
				}
				double mean = 0.0;
				double varice = 0.0;
				for (int i = 0; i < val; i++) {
					mean += mse[i];
				}

				mean /= val;
				BigDecimal bd = new BigDecimal(mean);
				bd = bd.setScale(3, BigDecimal.ROUND_HALF_UP);
				mean = bd.doubleValue();
				for (int i = 0; i < val; i++) {
					if (varice <= Math.abs(mse[i] - mean)) {
						varice = Math.abs(mse[i] - mean);
					}
				}
				bd = new BigDecimal(varice);
				bd = bd.setScale(3, BigDecimal.ROUND_HALF_UP);
				varice = bd.doubleValue();
				System.out.println("user weight:" + lumdaWu + "��item weight��" + lumdaWi + "��TestErr: " + mean + "+-" + varice);
			//}
		//}
	}
}
