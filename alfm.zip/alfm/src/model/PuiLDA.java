package model;

import io.FileUtil;

import java.util.ArrayList;
import java.util.HashMap;

import struct.Error;
import struct.Rating;
import math.LBFGS;
import math.LBFGS.ExceptionWithIflag;

public class PuiLDA {
	public static double train(int iterNum, ArrayList<Rating> ratings,
			ArrayList<HashMap<Integer, Double>> users,
			ArrayList<HashMap<Integer, Double>> items,
			int wordNum,
			int userNum,
			int itemNum,
			int k,
			int max,
			double lumdaWu,
			double lumdaWi,
			double lumdaU,
			double lumdaI,
			double lumdaW,
			double lumdaB){
		double[] x = new double[(userNum + itemNum)*(k+1) + wordNum * k + 1 ];
		//double[] xbak = new double[(userNum + itemNum)*(k+1) + wordNum * k + 1 ];
		init(x, userNum, itemNum, wordNum, ratings, k);
		ArrayList<Error> errors0 = new ArrayList<Error>();
		ArrayList<Error> errors1 = null;
		
		LBFGS l = new LBFGS();
		
		double[] diag = new double[(userNum + itemNum)*(k+1) + wordNum * k + 1];
		int[] iprint = new int[2];
		iprint[0] = -1;
		iprint[1] = 1;
		double xtol = 10e-16;
		int[] iflag = new int[1];
		iflag[0] = 0;
		double[] trainErr = new double[2];
		double[] testErr = new double[2];
		double[] validationErr = new double[2];
		for(int i = 0; i < max; i ++){
			errors1 = new ArrayList<Error>();
			double[] g = new double[(userNum + itemNum)*(k+1) + wordNum * k + 1 ];
			double f = getErrGrad(ratings, users, items, x, g, wordNum, userNum, itemNum, k, lumdaWu, lumdaWi, lumdaU, lumdaI, lumdaW, lumdaB);
			int trainT = 0;
			int testT = 0;
			int validationT = 0;
			for(Rating r : ratings){
				double prediction = 0.0;
				for(int j = 0; j < k; j ++){
					prediction += x[r.userSN * k + j] * x[(userNum + r.itemSN)*k + j];
				}
				prediction += x[(userNum+itemNum+wordNum)*k + r.userSN] + x[(userNum+itemNum+wordNum)*k + userNum + r.itemSN] + x[x.length-1];
				double err = prediction - r.rating;
				if(r.type.equals("TrainData")){
					trainErr[1] += Math.pow(err, 2);
					trainT ++;
				}else if(r.type.equals("TestData")){
					Error preErr = new Error(r.userSN, r.itemSN, Math.pow(err, 2));
					errors1.add(preErr);
					testErr[1] += Math.pow(err, 2);
					testT ++; 
				}if(r.type.equals("ValidationData")){
					validationErr[1] += Math.pow(err, 2);
					validationT ++;
				}
			}
			trainErr[1] /= trainT;
			validationErr[1] /= validationT;
			testErr[1] /= testT;
			System.out.println("Iteration " + i + ": " + "\ttrain:" + trainErr[1] + ";\tTest:" + testErr[1] + ";\tValidation:" + validationErr[1]);
			if((trainErr[1]-trainErr[0])*(validationErr[1]-validationErr[0])<0){
				break;
			}
			trainErr[0] = trainErr[1];
			validationErr[0] = validationErr[1];
			testErr[0] = testErr[1];
			errors0 = errors1;
			errors1 = null;
			/*for(int m = 0; m < x.length; m++){
				xbak[m] = x[m];
			}*/
			
			try {
				l.lbfgs(x.length, 4, x, f, g, false, diag, iprint, 0.001, xtol, iflag);
			} catch (ExceptionWithIflag e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		FileUtil.writeError("G:\\Experiment Result\\coldStart\\Baby\\C"+iterNum, errors0, "utf-8");
		return testErr[0];
	}
	
	public static void init(double[] x, int userNum, int itemNum, int wordNum, ArrayList<Rating> ratings, int k) {
		double[] uMean = new double[userNum];
		double[] iMean = new double[itemNum];
		double[] uBias = new double[userNum];
		double[] iBias = new double[itemNum];
		int[] uCN = new int[userNum];
		int[] iCN = new int[itemNum];
		double mean = 0.0;
		
		
		for(Rating r : ratings){
			uMean[r.userSN] += r.rating;
			iMean[r.itemSN] += r.rating;
			uCN[r.userSN] ++;
			iCN[r.itemSN] ++;
			mean += r.rating;
		}
		for(int i = 0; i < userNum; i ++){
			uMean[i] = uMean[i]/uCN[i];
		}
		for(int i = 0; i < itemNum; i ++){
			iMean[i] = iMean[i]/iCN[i];
		}
		for(Rating r : ratings){
			uBias[r.userSN] += r.rating - iMean[r.itemSN];
			iBias[r.itemSN] += r.rating - uMean[r.userSN];
		}
		
		mean = mean/ratings.size();
		x[(userNum+itemNum)*(k+1) + wordNum*k] = mean;
		
		int counter = (userNum + itemNum + wordNum)*k;
		for(int i = 0; i < counter; i ++){
			//x[i] = (Math.random() - 0.5) / (double)k;
			x[i] = Math.random() - 0.5;
		}
		
		for(int i = 0; i < userNum; i ++){
			x[i+counter] = uBias[i]/uCN[i];
		}
		
		counter = counter + userNum;
		for(int i = 0; i < itemNum; i ++){
			x[i+counter] = iBias[i]/iCN[i];
		}
		
		uMean = null;
		iMean = null;
		uBias = null;
		iBias = null;
		uCN = null;
		iCN = null;
	}

	private static double getErrGrad(ArrayList<Rating> ratings,
			ArrayList<HashMap<Integer, Double>> users,
			ArrayList<HashMap<Integer, Double>> items,
			double[] x,
			double[] g,
			int wordNum,
			int userNum,
			int itemNum,
			int k,
			double lumdaWu,
			double lumdaWi,
			double lumdaU,
			double lumdaI,
			double lumdaW,
			double lumdaB) {
		double f = 0.0;

		for (Rating r : ratings) {
			if (r.type.equals("TestData") || r.type.equals("ValidationData")) {
				continue;
			}
			
			//计算误差
			double prediction = 0.0;
			for(int i = 0; i < k; i ++){
				prediction += x[r.userSN * k + i] * x[(userNum + r.itemSN)*k + i];
			}
			prediction += x[(userNum+itemNum+wordNum)*k + r.userSN] + x[(userNum+itemNum+wordNum)*k + userNum + r.itemSN] + x[x.length-1];
			double rloss = prediction - r.rating;
			
			//计算梯度
			for(int i = 0; i < k; i ++){
				g[r.userSN*k + i] += rloss * x[(userNum + r.itemSN)*k + i];
				g[(userNum + r.itemSN)*k + i] += rloss * x[r.userSN*k + i];
			}
			g[(userNum + itemNum + wordNum)*k + r.userSN] +=  rloss;
			g[(userNum + itemNum + wordNum)*k + userNum + r.itemSN] += rloss;
			g[g.length - 1] += rloss;
			f += 0.5*Math.pow(rloss, 2);
		}
				
		for (int i = 0; i < userNum; i ++) {
			for(int j = 0; j < wordNum; j ++){
				//计算误差
				double prediction = 0.0;
				for(int m = 0; m < k ; m ++){
					prediction += x[i*k + m] * x[(userNum + itemNum + j)*k + m];
				}
				double wuloss = 0.0;
				if(users.get(i).containsKey(j)){
					wuloss = prediction - users.get(i).get(j);
				}else{
					wuloss = prediction;
				}
				f += 0.5*lumdaWu*Math.pow(wuloss, 2);
				
				//计算梯度
				for(int m = 0; m < k; m ++){
					g[i*k + m] += lumdaWu * wuloss * x[(userNum + itemNum + j)*k + m];
					g[(userNum + itemNum + j)*k + m] += lumdaWu * wuloss * x[i*k + m];
				}
			}
		}
		
		for (int i = 0; i < itemNum; i ++) {
			for(int j = 0; j < wordNum; j ++){
				//计算误差
				double prediction = 0.0;
				for(int m = 0; m < k ; m ++){
					prediction += x[(userNum + i)*k + m] * x[(userNum + itemNum + j)*k + m];
				}
				double wiloss = 0.0;
				if(items.get(i).containsKey(j)){
					wiloss = prediction - items.get(i).get(j);
				}else{
					wiloss = prediction;
				}
				f += 0.5*lumdaWi*Math.pow(wiloss, 2);
				
				//计算梯度
				for(int m = 0; m < k; m ++){
					g[(userNum + i)*k + m] += lumdaWi * wiloss * x[(userNum + itemNum + j)*k + m];
					g[(userNum + itemNum + j)*k + m] += lumdaWi * wiloss * x[(userNum + i)*k + m];
				}
			}
		}
		
		//加上正则化项
		for(int i = 0; i < userNum; i ++){
			for(int j = 0; j < k; j ++){
				g[i*k + j] += lumdaU * x[i*k +j];
				f += lumdaU * Math.pow(x[i*k +j], 2);
			}
			g[(userNum + itemNum + wordNum)*k + i] += lumdaB * x[(userNum + itemNum + wordNum)*k + i];
			f += lumdaB * Math.pow(x[(userNum + itemNum + wordNum)*k + i], 2);
		}
		for(int i = 0; i < itemNum; i ++){
			for(int j = 0; j < k; j ++){
				g[(userNum + i)*k + j] += lumdaI * x[(userNum + i)*k + j];
				f += lumdaI * Math.pow(x[(userNum + i)*k + j], 2);
			}
			g[(userNum + itemNum + wordNum)*k + userNum + i] += lumdaI * x[(userNum + itemNum + wordNum)*k + userNum + i];
			f += lumdaB * Math.pow(x[(userNum + itemNum + wordNum)*k + userNum + i], 2);
		}
		for(int i = 0; i < wordNum; i ++){
			for(int j = 0; j < k; j ++){
				g[(userNum + itemNum + i)*k + j] += lumdaW * x[(userNum + itemNum + i)*k + j];
				f += lumdaW * Math.pow(x[(userNum + itemNum + i)*k + j], 2);
			}
		}
		
		return f;
	}
}
